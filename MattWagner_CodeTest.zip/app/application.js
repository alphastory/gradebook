window.Gradebook = Ember.Application.create();

Gradebook.ApplicationAdapter = DS.LSAdapter.extend();
