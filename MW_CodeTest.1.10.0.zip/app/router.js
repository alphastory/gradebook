Gradebook.Router.map(function () {
	this.resource( 'students', { path: '/' } );
});
